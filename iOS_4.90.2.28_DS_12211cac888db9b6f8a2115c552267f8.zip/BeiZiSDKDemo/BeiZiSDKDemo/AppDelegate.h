//
//  AppDelegate.h
//  BeiZiSDKDemo
//
//  Created by Arthur on 2021/7/8.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end

