//
//  ViewController.h
//  BeiZiSDKDemo
//
//  Created by Arthur on 2021/7/8.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

