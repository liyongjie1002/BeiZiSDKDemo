//
//  BeiZiSplashViewController.h
//  BeiZiSDKDemo
//
//  Created by Arthur on 2021/7/8.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface BeiZiSplashViewController : UIViewController

@end

NS_ASSUME_NONNULL_END
