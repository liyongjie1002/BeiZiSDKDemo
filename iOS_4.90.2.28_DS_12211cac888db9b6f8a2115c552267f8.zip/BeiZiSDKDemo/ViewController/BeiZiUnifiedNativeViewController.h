//
//  BeiZiUnifiedNativeViewController.h
//  BeiZiSDKDemo
//
//  Created by Cookie on 2022/7/14.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface BeiZiUnifiedNativeViewController : UIViewController

@end

NS_ASSUME_NONNULL_END
