//
//  BeiZiUnifiedCustomViewController.h
//  BeiZiSDKDemo
//
//  Created by Cookie on 2022/3/28.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface BeiZiUnifiedCustomViewController : UIViewController

@end

NS_ASSUME_NONNULL_END
